﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class BusinessdaysController : ControllerBase
    {
        public IHolidayService _holidayService;

        public BusinessdaysController(IHolidayService holidayService)
        {
            _holidayService = holidayService;
        }

        [HttpGet("getbusinessdays")]
        public IActionResult GetBusinessDays(DateTime startDate, DateTime endDate)
        {
            int? workingDays = _holidayService.WorkingDayDifference(Convert.ToDateTime(startDate), Convert.ToDateTime(endDate));
            if (workingDays == null)
                return BadRequest(new { message = "Unable to calculate the working days" });

            return Ok(workingDays);
        }

    }
}
