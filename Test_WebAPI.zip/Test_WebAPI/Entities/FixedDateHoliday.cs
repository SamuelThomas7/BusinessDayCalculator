﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WebApi.Entities
{
    public class FixedDateHoliday
    {
        public int Id { get; set; }
        public string Holiday { get; set; }
        public int HolidayDate { get; set; }
        public int HolidayMonth { get; set; }
        public Boolean IsHolidayFixedDate { get; set; }
    }
}
