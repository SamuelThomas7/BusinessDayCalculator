﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WebApi.Entities
{
    public class FixedDayHoliday
    {
        public int Id { get; set; }
        public string Holiday { get; set; }
        public int Month { get; set; }
        public int Week { get; set; }
        public string Day { get; set; }
    }
}
