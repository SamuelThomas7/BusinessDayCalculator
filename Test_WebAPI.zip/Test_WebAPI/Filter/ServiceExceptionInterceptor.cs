﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;

namespace WebApi.Filter
{
    public class ServiceExceptionInterceptor : IAsyncExceptionFilter
    {
        public Task OnExceptionAsync(ExceptionContext context)
        {

            var error = new ErrorDetails()
            {
                StatusCode = 500,
                Message = context.Exception.Message.ToString()
            };
            context.Result = new Microsoft.AspNetCore.Mvc.JsonResult(error);
            return Task.CompletedTask;
        }
    }
}
