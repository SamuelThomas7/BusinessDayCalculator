﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Entities;

namespace WebApi.Services
{
    public interface IHolidayService
    {
        int? WorkingDayDifference(DateTime startDate, DateTime endDate);
    }
    public class HolidayService : IHolidayService
    {

        public int? WorkingDayDifference(DateTime startDate, DateTime endDate)
        {
            TimeSpan interval = endDate.Subtract(startDate);
            int totalWeekEnds = (int) (interval.Days / 7) * 2;
            int extraDays = interval.Days % 7;
            for(int counter = 1; counter <= extraDays; counter ++)
            {
                if (endDate.AddDays(-1 * counter).DayOfWeek == DayOfWeek.Saturday || endDate.AddDays(-1 * counter).DayOfWeek == DayOfWeek.Sunday)
                {
                    totalWeekEnds++;
                }
            }
            List<DateTime> holidays = new List<DateTime>();
            holidays = CalculateFixedAndFlexibleHolidays(startDate, endDate);
             return interval.Days - 1 - totalWeekEnds - holidays.Count;
        }

        public List<DateTime> CalculateFixedAndFlexibleHolidays(DateTime startDate, DateTime endDate)
        {
            List<FixedDateHoliday> dateHolidays = new List<FixedDateHoliday>();
            dateHolidays.Add(new FixedDateHoliday
            {
                Id = 1,
                Holiday = "Anzac Day",
                HolidayDate = 10,
                HolidayMonth = 4,
                IsHolidayFixedDate = true
            });

            dateHolidays.Add(new FixedDateHoliday
            {
                Id = 2,
                Holiday = "Australia Day",
                HolidayDate = 26,
                HolidayMonth = 1,
                IsHolidayFixedDate = false,
            });
            List<FixedDayHoliday> dayHolidays = new List<FixedDayHoliday>();
            dayHolidays.Add(new FixedDayHoliday
            {
                Id = 1,
                Day = "Monday",
                 Holiday= "Queens Birthday",
                Month = 6,
                Week = 2
            });

            List<DateTime> holidays = new List<DateTime>();
            while ((startDate <= endDate) || (startDate.Year == endDate.Year && startDate.Month == endDate.Month))
            {
                var fixedHolidays = dateHolidays.Where(x => x.IsHolidayFixedDate == true && startDate.Month == x.HolidayMonth).Select(x => Convert.ToDateTime(x.HolidayDate + "/" + x.HolidayMonth + "/" + startDate.Year)).ToList();
                var flexibleHolidays = dateHolidays.Where(x => x.IsHolidayFixedDate == false && startDate.Month == x.HolidayMonth).Select(x => Convert.ToDateTime(x.HolidayDate + "/" + x.HolidayMonth + "/" + startDate.Year)).ToList();

                foreach (var holiday in flexibleHolidays)
                {
                    if (Convert.ToDateTime(holiday).DayOfWeek == DayOfWeek.Saturday)
                        holidays.Add(holiday.AddDays(-1));
                    else if (Convert.ToDateTime(holiday).DayOfWeek == DayOfWeek.Saturday)
                        holidays.Add(holiday.AddDays(1));
                    else
                        holidays.Add(holiday);
                }

                foreach (var holiday in fixedHolidays)
                {
                    if (holiday.DayOfWeek != DayOfWeek.Sunday && holiday.DayOfWeek != DayOfWeek.Saturday)
                    {
                        holidays.Add(holiday);
                    }
                }
                var dynamicHolidays = dayHolidays.Where(x => x.Month == startDate.Month).ToList();
                List<DateTime> dates = new List<DateTime>();
                dates = GetDateForWeekDay(startDate.Year, dynamicHolidays);
                startDate = startDate.AddMonths(1);
                holidays.AddRange(dates);
            }
            return holidays;
        }
        public List<DateTime> GetDateForWeekDay(int Year, List<FixedDayHoliday> fixedDayHolidays)
        {
            List<DateTime> dates = new List<DateTime>();
            foreach (var dayHoliday in fixedDayHolidays)
            {
                DayOfWeek dayOfWeek =(DayOfWeek) Enum.Parse(typeof(DayOfWeek),dayHoliday.Day);
                DateTime dtEvaluateFormula = new DateTime(Year, dayHoliday.Month, 1);
                int j = 0;
                if (Convert.ToInt32(dayOfWeek) - Convert.ToInt32(dtEvaluateFormula.DayOfWeek) >= 0)
                    j = Convert.ToInt32(dayOfWeek) - Convert.ToInt32(dtEvaluateFormula.DayOfWeek) + 1;
                else
                    j = (7 - Convert.ToInt32(dtEvaluateFormula.DayOfWeek)) + (Convert.ToInt32(dayOfWeek) + 1);

               int calculatedDate = (j + (dayHoliday.Week - 1) * 7);
                DateTime calcDate = Convert.ToDateTime(calculatedDate + "/" + dayHoliday.Month + "/" + Year);
                if (calcDate.DayOfWeek != DayOfWeek.Saturday && calcDate.DayOfWeek != DayOfWeek.Sunday)
                    dates.Add(calcDate);
            }
            return dates;
        }
    }
}
